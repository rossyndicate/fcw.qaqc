library(testthat)
library(lubridate)

test_check("lubridate")
